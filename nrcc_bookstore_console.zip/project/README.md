# NRCC Bookstore Console — Sprint 2

## What's implemented
- Options 1–3: provided starter functionality (list all, search by course, save all-books report)
- Option 4: `saveCourseReport` — course lookup, Title+Author de-dup, Required/Optional subtotals, grand total
- Option 5: `exportTopN` — validated N, descending price sort, top-N list + total + average
- Option 6: `exportPriceStats` — count/min/max/average/median across all prices

## How to build & run (from the project root)
```
javac -d out src/Books.java src/MenuDriver.java
java -cp out MenuDriver
```
Press Enter at the CSV prompt to use the default file: `src/data/inventory_textbooks.csv`.

## Reports
All generated reports are written to `src/data/reports/`:
- `all_books_report.txt`
- `course_<COURSE>_report.txt` (e.g., `course_CSC222_report.txt`)
- `top<N>.txt` (e.g., `top5.txt`)
- `price_stats.txt`

## Notes
- No `Map` or Streams are used anywhere — only `ArrayList<Books>`, loops, and `Collections.sort` with a `Comparator`.
- All file writing uses try-with-resources (`PrintWriter` over `Files.newBufferedWriter`).
- Report columns are aligned with `printf` format specifiers.
- Menu choice input and Top-N input are validated with reprompt loops.
